package sort;

public class QuickSort {
	public static int coun = 0;

	public static void quickSort(int[] array, int low, int high) {
		if (array.length == 0)
			return;// завершить выполнение, если длина массива равна 0

		if (low >= high)
			return;// завершить выполнение если уже нечего делить
		// выбрать опорный элемент
		int opora;

		if (true) {
			int middle = low + (high - low) / 2;
			opora = array[middle];
		} else {
			long sum = 0;
			opora = 0;
			for (int i = 0; (high - low) > i; i++) {
				sum += array[i + low];
			}
			opora = (int) sum / (high - low);
		}
		// разделить на подмассивы, который больше и меньше опорного элемента
		int i = low, j = high;
		while (i < j) {
			while (array[i] <= opora && (i < j)) {
				i++;
			}

			while (array[j] >= opora && (i < j)) {
				j--;
			}

			if ((array[i] != array[j])) {// меняем местами
				int temp = array[i];
				array[i] = array[j];
				array[j] = temp;
				coun++;

			}

			i++;
			j--;

		}

		if (low <= j)
			quickSort(array, low, j);

		if (high >= i)
			quickSort(array, i, high);

	}

}
